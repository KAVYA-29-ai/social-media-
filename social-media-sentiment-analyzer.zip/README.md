# 🚀 Social Media Sentiment Analyzer

Streamlit dashboard that analyzes social media sentiment using Hugging Face.

## Features
- Hugging Face sentiment model (`cardiffnlp/twitter-roberta-base-sentiment-latest`)
- Auto-refresh demo posts (works without API keys)
- Streamlit Cloud ready

## Deploy on Streamlit Cloud
1. Push this repo to GitHub
2. In Streamlit Cloud: New App → Select repo
3. Add `requirements.txt` + `runtime.txt`

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
